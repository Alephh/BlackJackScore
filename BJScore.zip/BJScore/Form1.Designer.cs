﻿namespace BJScore
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Ace_Button = new System.Windows.Forms.Button();
            this.Two_Button = new System.Windows.Forms.Button();
            this.Three_Button = new System.Windows.Forms.Button();
            this.Four_Button = new System.Windows.Forms.Button();
            this.Five_Button = new System.Windows.Forms.Button();
            this.Six_Button = new System.Windows.Forms.Button();
            this.Seven_Button = new System.Windows.Forms.Button();
            this.Eight_Button = new System.Windows.Forms.Button();
            this.Nine_Button = new System.Windows.Forms.Button();
            this.Ten_Button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LiveCount_Update_Button = new System.Windows.Forms.Button();
            this.NewShoe_Button = new System.Windows.Forms.Button();
            this.LiveCount_Label = new System.Windows.Forms.Label();
            this.LiveCount_Value = new System.Windows.Forms.Label();
            this.TrueCount_Value = new System.Windows.Forms.Label();
            this.DecksRemaining_Value = new System.Windows.Forms.Label();
            this.CardsRemaining_Value = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Ace_Button
            // 
            this.Ace_Button.Location = new System.Drawing.Point(22, 317);
            this.Ace_Button.Name = "Ace_Button";
            this.Ace_Button.Size = new System.Drawing.Size(81, 201);
            this.Ace_Button.TabIndex = 0;
            this.Ace_Button.Tag = "-1";
            this.Ace_Button.Text = "Ace";
            this.Ace_Button.UseVisualStyleBackColor = true;
            this.Ace_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Two_Button
            // 
            this.Two_Button.Location = new System.Drawing.Point(109, 317);
            this.Two_Button.Name = "Two_Button";
            this.Two_Button.Size = new System.Drawing.Size(81, 201);
            this.Two_Button.TabIndex = 1;
            this.Two_Button.Tag = "1";
            this.Two_Button.Text = "Two";
            this.Two_Button.UseVisualStyleBackColor = true;
            this.Two_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Three_Button
            // 
            this.Three_Button.Location = new System.Drawing.Point(196, 317);
            this.Three_Button.Name = "Three_Button";
            this.Three_Button.Size = new System.Drawing.Size(81, 201);
            this.Three_Button.TabIndex = 2;
            this.Three_Button.Tag = "1";
            this.Three_Button.Text = "Three";
            this.Three_Button.UseVisualStyleBackColor = true;
            this.Three_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Four_Button
            // 
            this.Four_Button.Location = new System.Drawing.Point(283, 317);
            this.Four_Button.Name = "Four_Button";
            this.Four_Button.Size = new System.Drawing.Size(81, 201);
            this.Four_Button.TabIndex = 3;
            this.Four_Button.Tag = "1";
            this.Four_Button.Text = "Four";
            this.Four_Button.UseVisualStyleBackColor = true;
            this.Four_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Five_Button
            // 
            this.Five_Button.Location = new System.Drawing.Point(370, 317);
            this.Five_Button.Name = "Five_Button";
            this.Five_Button.Size = new System.Drawing.Size(81, 201);
            this.Five_Button.TabIndex = 4;
            this.Five_Button.Tag = "1";
            this.Five_Button.Text = "Five";
            this.Five_Button.UseVisualStyleBackColor = true;
            this.Five_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Six_Button
            // 
            this.Six_Button.Location = new System.Drawing.Point(457, 317);
            this.Six_Button.Name = "Six_Button";
            this.Six_Button.Size = new System.Drawing.Size(81, 201);
            this.Six_Button.TabIndex = 5;
            this.Six_Button.Tag = "1";
            this.Six_Button.Text = "Six";
            this.Six_Button.UseVisualStyleBackColor = true;
            this.Six_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Seven_Button
            // 
            this.Seven_Button.Location = new System.Drawing.Point(546, 317);
            this.Seven_Button.Name = "Seven_Button";
            this.Seven_Button.Size = new System.Drawing.Size(81, 201);
            this.Seven_Button.TabIndex = 6;
            this.Seven_Button.Tag = "0";
            this.Seven_Button.Text = "Seven";
            this.Seven_Button.UseVisualStyleBackColor = true;
            this.Seven_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Eight_Button
            // 
            this.Eight_Button.Location = new System.Drawing.Point(633, 317);
            this.Eight_Button.Name = "Eight_Button";
            this.Eight_Button.Size = new System.Drawing.Size(81, 201);
            this.Eight_Button.TabIndex = 7;
            this.Eight_Button.Tag = "0";
            this.Eight_Button.Text = "Eight";
            this.Eight_Button.UseVisualStyleBackColor = true;
            this.Eight_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Nine_Button
            // 
            this.Nine_Button.Location = new System.Drawing.Point(720, 317);
            this.Nine_Button.Name = "Nine_Button";
            this.Nine_Button.Size = new System.Drawing.Size(81, 201);
            this.Nine_Button.TabIndex = 8;
            this.Nine_Button.Tag = "0";
            this.Nine_Button.Text = "Nine";
            this.Nine_Button.UseVisualStyleBackColor = true;
            this.Nine_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // Ten_Button
            // 
            this.Ten_Button.Location = new System.Drawing.Point(807, 317);
            this.Ten_Button.Name = "Ten_Button";
            this.Ten_Button.Size = new System.Drawing.Size(81, 201);
            this.Ten_Button.TabIndex = 9;
            this.Ten_Button.Tag = "-1";
            this.Ten_Button.Text = "Ten";
            this.Ten_Button.UseVisualStyleBackColor = true;
            this.Ten_Button.Click += new System.EventHandler(this.CardButtons_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(this.LiveCount_Label);
            this.groupBox1.Controls.Add(this.NewShoe_Button);
            this.groupBox1.Controls.Add(this.LiveCount_Update_Button);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(476, 260);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mission Control";
            // 
            // LiveCount_Update_Button
            // 
            this.LiveCount_Update_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LiveCount_Update_Button.Location = new System.Drawing.Point(6, 19);
            this.LiveCount_Update_Button.Name = "LiveCount_Update_Button";
            this.LiveCount_Update_Button.Size = new System.Drawing.Size(464, 64);
            this.LiveCount_Update_Button.TabIndex = 0;
            this.LiveCount_Update_Button.Text = "Update True Count";
            this.LiveCount_Update_Button.UseVisualStyleBackColor = true;
            this.LiveCount_Update_Button.Click += new System.EventHandler(this.LiveCount_Update_Button_Click);
            // 
            // NewShoe_Button
            // 
            this.NewShoe_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewShoe_Button.Location = new System.Drawing.Point(6, 89);
            this.NewShoe_Button.Name = "NewShoe_Button";
            this.NewShoe_Button.Size = new System.Drawing.Size(464, 64);
            this.NewShoe_Button.TabIndex = 1;
            this.NewShoe_Button.Text = "New Shoe";
            this.NewShoe_Button.UseVisualStyleBackColor = true;
            this.NewShoe_Button.Click += new System.EventHandler(this.NewShoe_Button_Click);
            // 
            // LiveCount_Label
            // 
            this.LiveCount_Label.AutoSize = true;
            this.LiveCount_Label.Location = new System.Drawing.Point(6, 244);
            this.LiveCount_Label.Name = "LiveCount_Label";
            this.LiveCount_Label.Size = new System.Drawing.Size(146, 13);
            this.LiveCount_Label.TabIndex = 2;
            this.LiveCount_Label.Text = "TRUE COUNT UP TO DATE";
            // 
            // LiveCount_Value
            // 
            this.LiveCount_Value.AutoSize = true;
            this.LiveCount_Value.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LiveCount_Value.Location = new System.Drawing.Point(526, 13);
            this.LiveCount_Value.Name = "LiveCount_Value";
            this.LiveCount_Value.Size = new System.Drawing.Size(119, 24);
            this.LiveCount_Value.TabIndex = 11;
            this.LiveCount_Value.Text = "Live Count: 0";
            // 
            // TrueCount_Value
            // 
            this.TrueCount_Value.AutoSize = true;
            this.TrueCount_Value.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrueCount_Value.Location = new System.Drawing.Point(526, 37);
            this.TrueCount_Value.Name = "TrueCount_Value";
            this.TrueCount_Value.Size = new System.Drawing.Size(125, 24);
            this.TrueCount_Value.TabIndex = 12;
            this.TrueCount_Value.Text = "True Count: 0";
            // 
            // DecksRemaining_Value
            // 
            this.DecksRemaining_Value.AutoSize = true;
            this.DecksRemaining_Value.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DecksRemaining_Value.Location = new System.Drawing.Point(526, 61);
            this.DecksRemaining_Value.Name = "DecksRemaining_Value";
            this.DecksRemaining_Value.Size = new System.Drawing.Size(178, 24);
            this.DecksRemaining_Value.TabIndex = 13;
            this.DecksRemaining_Value.Text = "Decks Remaining: 0";
            // 
            // CardsRemaining_Value
            // 
            this.CardsRemaining_Value.AutoSize = true;
            this.CardsRemaining_Value.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CardsRemaining_Value.Location = new System.Drawing.Point(526, 85);
            this.CardsRemaining_Value.Name = "CardsRemaining_Value";
            this.CardsRemaining_Value.Size = new System.Drawing.Size(175, 24);
            this.CardsRemaining_Value.TabIndex = 14;
            this.CardsRemaining_Value.Text = "Cards Remaining: 0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(49, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 34);
            this.label1.TabIndex = 15;
            this.label1.Text = "A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(139, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 34);
            this.label2.TabIndex = 16;
            this.label2.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(221, 280);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 34);
            this.label3.TabIndex = 17;
            this.label3.Text = "3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(311, 280);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 34);
            this.label4.TabIndex = 18;
            this.label4.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(398, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 34);
            this.label5.TabIndex = 19;
            this.label5.Text = "5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(483, 280);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 34);
            this.label6.TabIndex = 20;
            this.label6.Text = "6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(570, 280);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 34);
            this.label7.TabIndex = 21;
            this.label7.Text = "7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(660, 280);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 34);
            this.label8.TabIndex = 22;
            this.label8.Text = "8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(747, 280);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 34);
            this.label9.TabIndex = 23;
            this.label9.Text = "9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Agency FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(816, 280);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 34);
            this.label10.TabIndex = 24;
            this.label10.Text = "10 JQK";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(382, 244);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(88, 13);
            this.linkLabel1.TabIndex = 3;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Counting Legend";
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.Blue;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 538);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CardsRemaining_Value);
            this.Controls.Add(this.DecksRemaining_Value);
            this.Controls.Add(this.TrueCount_Value);
            this.Controls.Add(this.LiveCount_Value);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Ten_Button);
            this.Controls.Add(this.Nine_Button);
            this.Controls.Add(this.Eight_Button);
            this.Controls.Add(this.Seven_Button);
            this.Controls.Add(this.Six_Button);
            this.Controls.Add(this.Five_Button);
            this.Controls.Add(this.Four_Button);
            this.Controls.Add(this.Three_Button);
            this.Controls.Add(this.Two_Button);
            this.Controls.Add(this.Ace_Button);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Blackjack Card Counter";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Ace_Button;
        private System.Windows.Forms.Button Two_Button;
        private System.Windows.Forms.Button Three_Button;
        private System.Windows.Forms.Button Four_Button;
        private System.Windows.Forms.Button Five_Button;
        private System.Windows.Forms.Button Six_Button;
        private System.Windows.Forms.Button Seven_Button;
        private System.Windows.Forms.Button Eight_Button;
        private System.Windows.Forms.Button Nine_Button;
        private System.Windows.Forms.Button Ten_Button;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LiveCount_Label;
        private System.Windows.Forms.Button NewShoe_Button;
        private System.Windows.Forms.Button LiveCount_Update_Button;
        private System.Windows.Forms.Label LiveCount_Value;
        private System.Windows.Forms.Label TrueCount_Value;
        private System.Windows.Forms.Label DecksRemaining_Value;
        private System.Windows.Forms.Label CardsRemaining_Value;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}

