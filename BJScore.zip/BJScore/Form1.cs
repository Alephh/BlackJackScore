﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BJScore
{
    public partial class Form1 : Form
    {

        private int LiveCount = 0;
        private int TrueCount = 0;
        private int DecksRemaining = 6;
        private int CardsRemaining = 312;

        public Form1()
        {
            InitializeComponent();
            LiveCount_Label.ForeColor = Color.Green;

            DecksRemaining_Value.Text = "Decks Remaining: " + DecksRemaining;
            CardsRemaining_Value.Text = "Cards Remaining: " + CardsRemaining;

            LiveCount_Update_Button.Enabled = false;
        }

        public void CardButtons_Click(object sender, EventArgs e)
        {
            //LiveCount_Label.Text = "THE TRUE COUNT IS NOT UP TO DATE!";
            //LiveCount_Label.ForeColor = Color.Red;

            Button b = (Button)sender;
            int value = Int32.Parse(b.Tag.ToString());
            LiveCount += value;
            LiveCount_Value.Text = "Live Count: " + LiveCount;

            CardsRemaining--;
            CardsRemaining_Value.Text = "Cards Remaining: " + CardsRemaining;
            if (CardsRemaining % 52 == 0)
                DecksRemaining--;
            DecksRemaining_Value.Text = "Decks Remaining: " + DecksRemaining;

            TrueCount = LiveCount / DecksRemaining;
            TrueCount_Value.Text = "True Count: " + TrueCount;
        }

        private void LiveCount_Update_Button_Click(object sender, EventArgs e)//Actually updated true count
        {
            TrueCount = LiveCount / DecksRemaining;
            TrueCount_Value.Text = "True Count: " + TrueCount;

            LiveCount_Label.Text = "TRUE COUNT UP TO DATE";
            LiveCount_Label.ForeColor = Color.Green;
        }

        private void NewShoe_Button_Click(object sender, EventArgs e)
        {
            TrueCount = 0;
            TrueCount_Value.Text = "True Count: " + TrueCount;

            LiveCount_Label.Text = "TRUE COUNT UP TO DATE";
            LiveCount_Label.ForeColor = Color.Green;

            LiveCount = 0;
            LiveCount_Value.Text = "Live Count: " + LiveCount;

            DecksRemaining = 6;
            CardsRemaining = 312;

            DecksRemaining_Value.Text = "Decks Remaining: " + DecksRemaining;
            CardsRemaining_Value.Text = "Cards Remaining: " + CardsRemaining;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CardInfo info = new CardInfo();
            info.Show();
        }
    }

    enum EnumeratedNumber
    {
        ACE = 1,
        TWO = 2,
        THREE = 3,
        FOUR = 4,
        FIVE = 5,
        SIX = 6,
        SEVEN = 7,
        EIGHT = 8,
        NINE = 9,
        TEN = 10
    }
}
